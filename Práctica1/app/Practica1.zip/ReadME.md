# Práctica 1. Desarrollo de Aplicaciones para Internet

## Autor: Carlota Valdivia Manzano

La carpeta app se compone de tres carpetas y un archivo .py

- En la carpeta templates se encuentran los archivos html
- En la carpeta ejercicios hay un archivo llamado ejercicios.py con los ejercicios de la práctica 0
- En la carpeta static hay una imagen para el ejercicio 2
- Archivo app.py 
