# Práctica 2. Desarrollo de Aplicaciones para Internet

## Autor: Carlota Valdivia Manzano

La carpeta app se compone de tres carpetas y un archivo .py

- En la carpeta templates se encuentran los archivos html
- En la carpeta ejercicios hay un archivo llamado ejercicios.py con los ejercicios de la práctica 0
- En la carpeta static hay una imagen para el ejercicio 2 y un logo para la aplicación
- En la carpeta BD se encuentran los usuarios de la base de datos.
- Archivo app.py 
- Archivo model.py

